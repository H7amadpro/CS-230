package com.gamingroom;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * This class extends the Entity base class to inherit
 * common attributes such as id and name, ensuring consistency
 * across all entities (Game, Player, Team).
 * </p>
 * 
 * @author Hamad Alghaithi

 */
public class Game extends Entity {

    /**
     * Constructor with an identifier and name
     */
    public Game(long id, String name) {
        super(id, name); // Calls the constructor of Entity
    }

    @Override
    public String toString() {
        return "Game [id=" + getId() + ", name=" + getName() + "]";
    }
}
