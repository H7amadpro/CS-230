package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author Hamad Alghaithi
 */
public class GameService {

    /**
     * A list of the active games
     */
    private static List<Game> games = new ArrayList<>();

    /*
     * Holds the next game identifier
     */
    private static long nextGameId = 1;

    // Singleton instance
    private static GameService instance;

    /**
     * Private constructor to prevent instantiation
     */
    private GameService() { }

    /**
     * Get the single instance of GameService
     * 
     * @return instance of GameService
     */
    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    /**
     * Construct a new game instance
     * 
     * @param name the unique name of the game
     * @return the game instance (new or existing)
     */
    public Game addGame(String name) {

        // Check if a game with the same name already exists
        for (Game g : games) {
            if (g.getName().equalsIgnoreCase(name)) {
                return g; // Return existing game
            }
        }

        // If no existing game, create a new one
        Game game = new Game(nextGameId++, name);
        games.add(game);
        return game;
    }

    /**
     * Returns the game instance with the specified id.
     * 
     * @param id unique identifier of game to search for
     * @return requested game instance or null if not found
     */
    public Game getGame(long id) {
        for (Game g : games) {
            if (g.getId() == id) {
                return g;
            }
        }
        return null; // Return null if not found
    }

    /**
     * Returns the game instance with the specified name.
     * 
     * @param name unique name of game to search for
     * @return requested game instance or null if not found
     */
    public Game getGame(String name) {
        for (Game g : games) {
            if (g.getName().equalsIgnoreCase(name)) {
                return g;
            }
        }
        return null; // Return null if not found
    }

    /**
     * Returns the number of games currently active
     * 
     * @return the number of games currently active
     */
    public int getGameCount() {
        return games.size();
    }
}
