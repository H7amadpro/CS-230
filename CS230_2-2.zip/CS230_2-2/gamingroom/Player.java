package com.gamingroom;

/**
 * Represents a player with a unique ID and name.
 *
 * Hamad Alghaiti
 * CS-230
 */

public class Player {
    // Unique identifier for the player
    private final long id;
    // Name of the player
    private String name;

    /**
     * Constructor to initialize the player with an ID and name.
     *
     * @param id   The unique ID of the player
     * @param name The name of the player
     */
    public Player(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Retrieves the player's ID.
     *
     * @return The unique ID of the player
     */
    public long getId() {
        return id;
    }

    /**
     * Retrieves the player's name.
     *
     * @return The name of the player
     */
    public String getName() {
        return name;
    }

    /**
     * Updates the player's name.
     *
     * @param name The new name for the player
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns a string representation of the Player object.
     *
     * @return A formatted string with player details
     */
    @Override
    public String toString() {
        return "Player{" + "id=" + id + ", name='" + name + '\'' + '}';
    }
}
