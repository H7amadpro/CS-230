package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * This class manages game instances using the Singleton pattern.
 * It ensures only one instance of GameService exists at a time.
 *
 * Hamad Alghaiti
 * CS-230
 */

public class GameService {
    
    // Singleton instance of GameService
    private static GameService instance;

    // List to store all games
    private List<Game> games = new ArrayList<>();

    // Variable to track the next game ID
    private long nextGameId;

    /**
     * Private constructor to prevent direct instantiation.
     * Initializes the game ID.
     */
    private GameService() {
        nextGameId = 1;
    }

    /**
     * Returns the single instance of GameService.
     * If no instance exists, it creates one.
     *
     * @return The singleton instance of GameService
     */
    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    /**
     * Adds a new game if the name is not already taken.
     * Uses an iterator to check for existing games.
     *
     * @param name The name of the new game
     * @return The new Game object if created, or null if the name already exists
     */
    public Game addGame(String name) {
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getName().equalsIgnoreCase(name)) {
                return null; // Game with this name already exists
            }
        }
        Game newGame = new Game(nextGameId++, name);
        games.add(newGame);
        return newGame;
    }

    /**
     * Retrieves a game by its name.
     * Uses an iterator to search the list.
     *
     * @param name The name of the game
     * @return The Game object if found, otherwise null
     */
    public Game getGame(String name) {
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game game = iterator.next();
            if (game.getName().equalsIgnoreCase(name)) {
                return game;
            }
        }
        return null; // No game found with this name
    }

    /**
     * Retrieves a game by its unique ID.
     *
     * @param id The ID of the game
     * @return The Game object if found, otherwise null
     */
    public Game getGame(long id) {
        for (Game game : games) {
            if (game.getId() == id) {
                return game;
            }
        }
        return null; // No game found with this ID
    }

    /**
     * Returns the total number of games in the system.
     *
     * @return The number of games
     */
    public int getGameCount() {
        return games.size();
    }
}
