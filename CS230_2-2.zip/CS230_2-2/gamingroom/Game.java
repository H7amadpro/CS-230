package com.gamingroom;

/**
 * This class represents a Game with a unique ID and name.
 *
 * Hamad Alghaiti
 * CS-230
 */
public class Game {
    // Unique identifier for the game
    private long id;
    // Name of the game
    private String name;

    /**
     * Constructor to initialize the game with an ID and a name.
     *
     * @param id   The unique ID for the game
     * @param name The name of the game
     */
    public Game(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Retrieves the ID of the game.
     *
     * @return The game's ID
     */
    public long getId() {
        return id;
    }

    /**
     * Retrieves the name of the game.
     *
     * @return The game's name
     */
    public String getName() {
        return name;
    }

    /**
     * Updates the name of the game.
     *
     * @param name The new name for the game
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns a string representation of the Game object.
     *
     * @return A formatted string with the game's ID and name
     */
    @Override
    public String toString() {
        return "Game{" + "id=" + id + ", name='" + name + '\'' + '}';
    }
}
