package com.gamingroom;

/**
 * Represents a team with a unique ID and a name.
 *
 * Hamad Alghaiti
 * CS-230
 */

public class Team {
    // Unique identifier for the team
    private final long id;
    // Name of the team
    private String name;

    /**
     * Constructor to initialize the team with an ID and name.
     *
     * @param id   The unique ID of the team
     * @param name The name of the team
     */
    public Team(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Retrieves the team's ID.
     *
     * @return The unique ID of the team
     */
    public long getId() {
        return id;
    }

    /**
     * Retrieves the team's name.
     *
     * @return The name of the team
     */
    public String getName() {
        return name;
    }

    /**
     * Updates the team's name.
     *
     * @param name The new name for the team
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns a string representation of the Team object.
     *
     * @return A formatted string with team details
     */
    @Override
    public String toString() {
        return "Team{" + "id=" + id + ", name='" + name + '\'' + '}';
    }
}
