package com.gamingroom;

/**
 * The main driver class for the game application.
 * Demonstrates the use of the Singleton pattern in GameService.
 *
 * Hamad Alghaiti
 * CS-230
 */

public class ProgramDriver {
    public static void main(String[] args) {
        // Retrieve the singleton instance of GameService
        GameService gameService = GameService.getInstance();

        // Add games to the service
        Game game1 = gameService.addGame("Game1");
        Game game2 = gameService.addGame("Game2");

        // Attempt to add a duplicate game (should return null)
        Game duplicateGame = gameService.addGame("Game1");

        // Output results
        System.out.println("Added Games:");
        System.out.println(game1);
        System.out.println(game2);

        if (duplicateGame == null) {
            System.out.println("Duplicate game not added.");
        }

        // Retrieve a game by name
        Game retrievedGame = gameService.getGame("Game1");
        if (retrievedGame != null) {
            System.out.println("Retrieved: " + retrievedGame);
        } else {
            System.out.println("Game not found.");
        }

        // Display the total number of games
        System.out.println("Total games in service: " + gameService.getGameCount());
    }
}
